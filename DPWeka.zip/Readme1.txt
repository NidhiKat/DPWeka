17 Nov : Updated FunctionalMechanismTest2.java source file  
16 Dec : Updated files from lab computer. Removed unnecessary java files. If older files are required ref to googledrive thesisWorkSpace> 16 dec Check demoPrivClassifier for the updated java files and thesisWorkspace for others
5 Jan : Folder created inDPWEKA to test if both classifiers and statistics can be deployed in a single package 
2 Feb : Created demoDPWEKAv20 with stats and classifiers - and unwanted classes removed (except GAv30 - for privGene) Testing of all methods and classes must be done again on thetool and required changes must be made 
Note : Algorithsm tested 
Lap Chi Square with pearson statistics works 

Exp p value fixed
(10:41 AM)

17 Feb : fixed p values, chi square and PrivGene ( Need more testing but initial tests when seed is set to 0 seems to work well)- loading to bit bucket but requires cleaning code

23 Feb : Created DPWekaDemov30 ; Copied from demoDPWekav20 version of 17 feb 
9:32AM : Renamed the package demo1.PrivStats